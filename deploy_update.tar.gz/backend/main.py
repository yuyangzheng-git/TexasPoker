"""
FastAPI 主入口 + WebSocket 游戏服务器
"""
import os
import json
import asyncio
from typing import Dict
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from dotenv import load_dotenv

from game_engine import GameEngine, Player, GamePhase
from llm_agent import LLMAgent

load_dotenv("../config/.env")

app = FastAPI(title="Poker LLM Agent API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "http://101.35.6.63:3001", "http://101.35.6.63"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# 活跃游戏会话
active_games: Dict[str, dict] = {}

# WebSocket 连接池
connections: Dict[str, WebSocket] = {}

# 游戏暂停状态
game_paused: Dict[str, asyncio.Event] = {}


@app.post("/api/games")
async def create_game(body: dict):
    """创建新牌局"""
    import uuid
    import json

    game_id = str(uuid.uuid4())[:8]
    api_key = os.getenv("DEEPSEEK_API_KEY", "")

    # 加载 Agent 人格配置
    with open("../config/agent_personas.json") as f:
        all_personas = json.load(f)["agents"]

    with open("../config/game_config.json") as f:
        game_cfg = json.load(f)

    # 创建玩家列表
    players = []
    agent_map = {}

    # 真人玩家
    human_player = Player(
        id="player_human",
        name=body.get("player_name", "Player"),
        stack=game_cfg["game"]["default_stack"],
        player_type="human"
    )
    players.append(human_player)

    # LLM Agent 玩家（根据前端选择的 agent_ids 过滤）
    agent_ids = body.get("agent_ids")
    num_agents = body.get("num_agents", 3)
    if agent_ids and isinstance(agent_ids, list):
        selected_personas = [p for p in all_personas if p["id"] in agent_ids]
    else:
        selected_personas = all_personas[:num_agents]

    for persona in selected_personas:
        agent_player = Player(
            id=f"agent_{persona['id']}",
            name=persona["name"],
            stack=game_cfg["game"]["default_stack"],
            player_type="llm_agent",
            agent_config=persona
        )
        players.append(agent_player)
        agent_map[agent_player.id] = LLMAgent(persona, agent_player)

    # 初始化游戏引擎
    game = GameEngine(players, min_bet=game_cfg["game"]["small_blind"])

    active_games[game_id] = {
        "engine": game,
        "agents": agent_map,
        "config": game_cfg
    }

    return {
        "gameId": game_id,
        "wsUrl": f"ws://localhost:8000/ws/{game_id}",
        "players": [{"id": p.id, "name": p.name, "stack": p.stack} for p in players]
    }


@app.websocket("/ws/{game_id}")
async def websocket_endpoint(websocket: WebSocket, game_id: str):
    await websocket.accept()
    connections[game_id] = websocket

    # 初始化暂停状态（默认不暂停）
    game_paused[game_id] = asyncio.Event()
    game_paused[game_id].set()  # set = not paused

    try:
        game_data = active_games.get(game_id)
        if not game_data:
            await websocket.send_json({"type": "ERROR", "data": {"message": "Game not found"}})
            return

        game: GameEngine = game_data["engine"]
        agents: dict = game_data["agents"]
        cfg: dict = game_data["config"]

        # 发牌开始
        game.deal_hole_cards()
        game.post_blinds()

        await broadcast(websocket, "GAME_STARTED", game.get_state_snapshot())

        # 多局游戏循环
        hand_count = 0
        while True:
            hand_count += 1

            # 检查是否还有多于1名玩家有筹码
            players_with_chips = [p for p in game.players if p.stack > 0]
            if len(players_with_chips) <= 1:
                # 游戏结束，只剩一人
                await broadcast(websocket, "TOURNAMENT_ENDED", {
                    "winner": players_with_chips[0].name if players_with_chips else "Unknown",
                    "finalStacks": {p.id: p.stack for p in game.players}
                })
                break

            # 单局游戏循环
            while game.phase not in (GamePhase.ENDED, GamePhase.SHOWDOWN):

                # 检查是否只剩一人
                remaining = game.non_folded_players()
                if len(remaining) <= 1:
                    allocations = game.determine_winners()
                    await broadcast(websocket, "GAME_ENDED", {
                        "allocations": allocations,
                        "finalState": game.get_state_snapshot()
                    })
                    game.phase = GamePhase.ENDED
                    break

                active = game.get_action_order()
                round_complete = False
                print(f"[DEBUG] Starting action round: phase={game.phase.value}, active_count={len(active)}, pending={game.pending_actors}")

                for player in active:
                    # 每轮开始前重新检查
                    if game.phase in (GamePhase.ENDED, GamePhase.SHOWDOWN):
                        round_complete = True
                        break

                    if player.player_type == "llm_agent":
                        agent = agents.get(player.id)
                        if not agent:
                            continue

                        # 等待暂停恢复
                        await game_paused[game_id].wait()

                        await broadcast(websocket, "AGENT_THINKING_START", {"agentId": player.id})

                        def on_chunk(agent_id: str, text: str):
                            asyncio.create_task(
                                broadcast(websocket, "AGENT_THINKING_CHUNK",
                                          {"agentId": agent_id, "chunk": text})
                            )

                        timeout = cfg["game"]["agent_timeout_ms"] / 1000
                        response = await agent.decide(game, timeout=timeout, on_chunk=on_chunk)

                        await broadcast(websocket, "AGENT_THINKING_END", {
                            "agentId": player.id,
                            "action": response.action.type.value if response.action else "fold",
                            "speech": response.speech
                        })

                        if response.action:
                            game.process_action(response.action)
                        if response.speech:
                            game.record_speech(player.id, response.speech)

                        await broadcast(websocket, "PLAYER_ACTION", {
                            "playerId": player.id,
                            "action": response.action.type.value if response.action else "fold",
                            "amount": response.action.amount if response.action else 0,
                            "pot": game.pot,
                            "stateSnapshot": game.get_state_snapshot()
                        })

                    else:
                        # 真人玩家
                        valid_actions = game.get_valid_actions(player)
                        timeout_ms = cfg["game"]["human_timeout_ms"]

                        await broadcast(websocket, "PLAYER_ACTION_REQUEST", {
                            "playerId": player.id,
                            "validActions": [a.value for a in valid_actions],
                            "callAmount": max(0, game.street_bet - player.current_bet),
                            "pot": game.pot,
                            "timeLimit": timeout_ms
                        })

                        try:
                            msg = await asyncio.wait_for(
                                websocket.receive_json(),
                                timeout=timeout_ms / 1000
                            )
                            # 处理暂停/恢复消息
                            if msg.get("type") == "PAUSE":
                                game_paused[game_id].clear()
                                continue
                            if msg.get("type") == "RESUME":
                                game_paused[game_id].set()
                                continue
                            from game_engine import Action, ActionType
                            human_action = Action(
                                player_id=player.id,
                                type=ActionType(msg.get("action", "fold")),
                                amount=msg.get("amount", 0)
                            )
                            game.process_action(human_action)
                            print(f"[DEBUG] Human action processed: {human_action.type.value}")
                            await broadcast(websocket, "PLAYER_ACTION", {
                                "playerId": player.id,
                                "action": human_action.type.value,
                                "amount": human_action.amount,
                                "pot": game.pot,
                                "stateSnapshot": game.get_state_snapshot()
                            })
                        except asyncio.TimeoutError:
                            from game_engine import Action, ActionType
                            if game.street_bet == player.current_bet:
                                timeout_action = Action(player_id=player.id, type=ActionType.CHECK)
                            else:
                                timeout_action = Action(player_id=player.id, type=ActionType.FOLD)
                            game.process_action(timeout_action)
                            await broadcast(websocket, "PLAYER_ACTION", {
                                "playerId": player.id,
                                "action": timeout_action.type.value,
                                "amount": timeout_action.amount,
                                "pot": game.pot,
                                "stateSnapshot": game.get_state_snapshot()
                            })
                        except (RuntimeError, WebSocketDisconnect):
                            # WebSocket 断开连接，将玩家视为弃牌
                            print(f"[DEBUG] WebSocket disconnected during human turn, folding")
                            from game_engine import Action, ActionType
                            fold_action = Action(player_id=player.id, type=ActionType.FOLD)
                            game.process_action(fold_action)
                            raise WebSocketDisconnect()

                    # 每次 action 后检查是否只剩一人
                    if len(game.non_folded_players()) <= 1:
                        allocations = game.determine_winners()
                        await broadcast(websocket, "GAME_ENDED", {
                            "allocations": allocations,
                            "finalState": game.get_state_snapshot()
                        })
                        game.phase = GamePhase.ENDED
                        break

                    # 每次 action 后检查下注轮是否结束
                    betting_complete = game.is_betting_round_complete()
                    print(f"[DEBUG] phase={game.phase.value}, betting_complete={betting_complete}, pending={game.pending_actors}, street_bet={game.street_bet}")
                    if betting_complete:
                        if game.phase == GamePhase.RIVER:
                            game.phase = GamePhase.SHOWDOWN
                            print(f"[DEBUG] Entering SHOWDOWN")
                            # 广播进入摊牌阶段
                            await broadcast(websocket, "PHASE_CHANGED", game.get_state_snapshot())
                        else:
                            game.advance_phase()
                            await broadcast(websocket, "PHASE_CHANGED", game.get_state_snapshot())
                        round_complete = True
                        break

                if game.phase in (GamePhase.ENDED, GamePhase.SHOWDOWN):
                    break
                if round_complete:
                    continue

                # 无人行动(所有人 all-in), 自动推进行到 showdown
                if not active:
                    while game.phase != GamePhase.SHOWDOWN:
                        game.advance_phase()
                        await broadcast(websocket, "PHASE_CHANGED", game.get_state_snapshot())
                        # 延迟以便前端展示每一轮发牌动画
                        await asyncio.sleep(1.5)
                    break

            # 摊牌
            if game.phase == GamePhase.SHOWDOWN:
                print(f"[DEBUG] Processing SHOWDOWN")

                # 先发送亮牌事件，让前端显示所有人的底牌
                reveal_data = {
                    "players": [
                        {
                            "id": p.id,
                            "name": p.name,
                            "hole_cards": [{"rank": c.rank, "suit": c.suit} for c in p.hole_cards],
                            "status": p.status.value,
                        }
                        for p in game.players
                        if p.status.value != "folded"  # 只显示未弃牌玩家的牌
                    ]
                }
                await broadcast(websocket, "REVEAL_ALL_CARDS", reveal_data)

                # 等待3秒让玩家看清所有人的牌
                await asyncio.sleep(3)

                # 然后计算赢家并发送结算结果
                print(f"[DEBUG] Calling determine_winners()")
                allocations = game.determine_winners()
                print(f"[DEBUG] SHOWDOWN allocations: {allocations}")
                await broadcast(websocket, "SHOWDOWN", {
                    "allocations": allocations,
                    "finalState": game.get_state_snapshot()
                })

            # 等待玩家确认进入下一局
            print(f"[DEBUG] Waiting for READY_FOR_NEXT_HAND...")
            try:
                while True:
                    msg = await asyncio.wait_for(websocket.receive_json(), timeout=300)
                    print(f"[DEBUG] Received message while waiting: {msg}")
                    if msg.get("type") == "READY_FOR_NEXT_HAND":
                        print(f"[DEBUG] Got READY_FOR_NEXT_HAND, proceeding to next hand")
                        break
                    if msg.get("type") == "PAUSE":
                        game_paused[game_id].clear()
                    if msg.get("type") == "RESUME":
                        game_paused[game_id].set()
                    # 忽略其他消息，继续等待
            except asyncio.TimeoutError:
                print(f"[DEBUG] Timeout waiting for READY_FOR_NEXT_HAND, auto-continuing")
            except Exception as e:
                print(f"[DEBUG] Exception while waiting for READY_FOR_NEXT_HAND: {e}")
                raise  # 重新抛出异常，让外层处理

            # 重置游戏状态以开始新的一手牌
            game.reset_for_new_hand()
            game.deal_hole_cards()
            game.post_blinds()

            await broadcast(websocket, "HAND_STARTED", {
                "handNumber": hand_count,
                "gameState": game.get_state_snapshot()
            })

    except WebSocketDisconnect:
        connections.pop(game_id, None)


async def broadcast(websocket: WebSocket, event_type: str, data: dict):
    """向客户端发送 WebSocket 消息"""
    try:
        await websocket.send_json({"type": event_type, "data": data})
    except Exception:
        pass


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
