"""
LLM Agent 引擎
负责 Prompt 构建、LLM 调用、响应解析和记忆管理
"""
import re
import json
import asyncio
from dataclasses import dataclass, field
from typing import Optional, Callable

from game_engine import GameEngine, Player, Action, ActionType
from monte_carlo_equity import MonteCarloEquityCalculator


# 加载全局配置
with open("../config/game_config.json") as _f:
    _game_cfg = json.load(_f)
MC_SIMULATIONS = _game_cfg.get("monte_carlo", {}).get("simulations", 5000)


# ──────────────────────────────────────────
# 数据结构
# ──────────────────────────────────────────

@dataclass
class OpponentProfile:
    player_id: str
    hands_observed: int = 0
    vpip: float = 0.0          # 主动投入底池率
    pfr: float = 0.0           # 翻牌前加注率
    aggression: float = 0.0    # 激进系数
    bluff_frequency: float = 0.0
    fold_to_bet: float = 0.0
    recent_actions: list = field(default_factory=list)

    def update(self, action_type: str, context: dict):
        self.hands_observed += 1
        if action_type in ["call", "raise", "allin"]:
            self.vpip = (self.vpip * (self.hands_observed - 1) + 1) / self.hands_observed
        if action_type == "raise":
            self.pfr = (self.pfr * (self.hands_observed - 1) + 1) / self.hands_observed
        if action_type == "fold" and context.get("facing_bet"):
            self.fold_to_bet = (self.fold_to_bet * (self.hands_observed - 1) + 1) / self.hands_observed

        self.recent_actions.append({"action": action_type, "phase": context.get("phase", "")})
        if len(self.recent_actions) > 20:
            self.recent_actions.pop(0)


@dataclass
class AgentMemory:
    hands_played: int = 0
    win_rate: float = 0.0
    cumulative_winnings: float = 0.0
    opponent_profiles: dict = field(default_factory=dict)
    recent_results: list = field(default_factory=list)
    seasonal_meta: list = field(default_factory=list)

    def record_result(self, won: bool, amount: float):
        self.hands_played += 1
        if won:
            self.cumulative_winnings += amount
        result = "W" if won else "L"
        self.recent_results.append(result)
        if len(self.recent_results) > 10:
            self.recent_results.pop(0)
        self.win_rate = self.recent_results.count("W") / len(self.recent_results)

    def get_opponent_profile(self, player_id: str) -> OpponentProfile:
        if player_id not in self.opponent_profiles:
            self.opponent_profiles[player_id] = OpponentProfile(player_id=player_id)
        return self.opponent_profiles[player_id]

    def get_prompt_summary(self) -> str:
        return (
            f"总手数: {self.hands_played}, "
            f"近期胜率: {self.win_rate:.0%}, "
            f"累计盈亏: ${self.cumulative_winnings:+.0f}, "
            f"近期: {' '.join(self.recent_results)}"
        )


@dataclass
class ParsedResponse:
    thinking: str = ""
    action: Optional[Action] = None
    speech: str = ""


# ──────────────────────────────────────────
# 底池赔率计算
# ──────────────────────────────────────────

def calculate_pot_odds(pot: float, call_amount: float) -> dict:
    if call_amount <= 0:
        return {"pot_odds": 0.0, "break_even_equity": 0.0}
    pot_odds = call_amount / (pot + call_amount)
    return {
        "pot_odds": pot_odds,
        "break_even_equity": pot_odds,
    }


def calculate_ev(equity: float, pot: float, call_amount: float) -> float:
    return equity * pot - (1 - equity) * call_amount


# ──────────────────────────────────────────
# Prompt 构建器
# ──────────────────────────────────────────

class PromptBuilder:
    """动态构建 LLM Agent 决策 Prompt"""

    @staticmethod
    def build(agent_config: dict, player: Player, game: GameEngine, memory: AgentMemory) -> str:
        state = game.get_state_snapshot()
        my_cards_str = " ".join(c.to_string() for c in player.hole_cards)

        # 计算股似率
        num_opponents = len(game.non_folded_players()) - 1
        equity = MonteCarloEquityCalculator.calculate_equity(
            player.hole_cards,
            game.community_cards,
            num_opponents,
            simulations=MC_SIMULATIONS
        )

        call_amount = max(0.0, game.street_bet - player.current_bet)
        pot_odds = calculate_pot_odds(game.pot, call_amount)
        ev = calculate_ev(equity, game.pot, call_amount)

        # 对手分析摘要
        opponent_lines = []
        for p in game.players:
            if p.id == player.id or p.status.value == "folded":
                continue
            profile = memory.get_opponent_profile(p.id)
            style = "激进" if profile.aggression > 0.5 else "保守"
            recent = " → ".join(a["action"] for a in profile.recent_actions[-3:]) or "无记录"
            opponent_lines.append(
                f"  [{p.name}] 筹码 ${p.stack:.0f} | 风格: {style}"
                f" | VPIP: {profile.vpip:.0%} | 近期: {recent}"
            )
        opponent_section = "\n".join(opponent_lines) if opponent_lines else "  无对手信息"

        # 可用行动列表
        valid_actions = game.get_valid_actions(player)
        actions_str = " | ".join(a.value for a in valid_actions)

        # 最近对话
        recent_speech = game.get_recent_speech(max_lines=5)
        speech_display = recent_speech if recent_speech else "  暂无对话"

        # 根据筹码量给出策略建议（大盲注=20）
        bb = game.big_blind
        stack_bb = player.stack / bb if bb > 0 else 50
        if stack_bb < 15:
            stack_advice = "短码(<15BB)：推All-in或弃牌，不宜平跟"
        elif stack_bb < 30:
            stack_advice = "较短筹码(15-30BB)：可加注All-in施压，谨慎跟注"
        elif stack_bb < 50:
            stack_advice = "中等筹码(30-50BB)：标准打法，正常加注"
        elif stack_bb < 80:
            stack_advice = "较深筹码(50-80BB)：可玩更多手牌，适当诈唬"
        else:
            stack_advice = "深码(>80BB)：手牌范围宽，可用筹码施压对手"

        # 位置信息
        all_positions = ", ".join(
            f"{p.name}({p.position})" for p in game.players
            if p.status.value != "folded"
        )

        prompt = f"""你是德州扑克玩家【{agent_config['name']}】。

【性格设定】
{agent_config['persona']}
风险偏好: {agent_config['risk_profile']}

【当前牌局状态】
- 你的位置: {player.position}
- 全场位置一览: {all_positions}
- 总人数: {len(game.non_folded_players())} (未弃牌)
- 你的手牌: {my_cards_str}
- 你的筹码: ${player.stack:.0f}
- 底池大小: ${state['pot']:.0f}
- 下注轮: {state['phase']}
- 公共牌: {', '.join(c.to_string() for c in game.community_cards) if game.community_cards else '未发'}
- 当前最高下注: ${state['street_bet']:.0f}
- 你需要跟注: ${call_amount:.0f}

【位置说明】
- BTN(庄家): 翻牌后最后行动，最具优势
- CO(关煞位): 庄家右侧，翻牌前仅次于庄家
- HJ/MP(中间位): 中间位置
- UTG(枪口位): 翻牌前最先行动，最不利位置
- SB(小盲): 翻牌前第二行动，已投入小盲注
- BB(大盲): 翻牌前最后行动，已投入大盲注

【策略要点】
- 筹码量: ${player.stack:.0f} — {stack_advice}
- 位置越靠后，可玩的手牌范围越宽

【数学分析】
- 你的股似率(胜率): {equity:.1%}
- 底池赔率: {pot_odds['pot_odds']:.1%}
- 保本所需最低胜率: {pot_odds['break_even_equity']:.1%}
- 期望值评估: {"正期望值 ✓ (值得跟注)" if ev > 0 else "负期望值 ✗ (不建议跟注)"}

【对手分析】
{opponent_section}

【桌上对话】
{speech_display}

【你的历史记录】
{memory.get_prompt_summary()}

【可用行动】
{actions_str}

请严格按照以下格式回复，三个部分都必须完整输出:

<thinking>
(分析手牌、位置、对手、数学指标、对手对话信息，50-100字)
</thinking>

<action>
fold | check | call | raise {{金额}} | allin
</action>

<speech>
(每一轮都说1句话！保持角色一致，可以虚张声势、放狠话、误导对手或表达情绪。你的话会直接影响对手的判断！
【重要】绝对不能在发言中透露你的具体手牌！不能说"我有AA"、"我拿了同花"等。可以暗示强弱但不能明说！)
</speech>"""

        return prompt
