"""
LLM Agent - DeepSeek V4 版本
- Pre-Flop / Flop  → deepseek-v4-flash  (快速 + 省成本)
- Turn / River     → deepseek-v4-pro    (更强推理能力)
"""
import re
import asyncio
import os
import json
from typing import Optional, Callable
from openai import AsyncOpenAI

from game_engine import GameEngine, Player, Action, ActionType, GamePhase
from monte_carlo_equity import MonteCarloEquityCalculator
from agent_engine import (
    AgentMemory, ParsedResponse, PromptBuilder, calculate_pot_odds
)

# 加载全局配置
with open("../config/game_config.json") as _f:
    _game_cfg = json.load(_f)
MC_SIMULATIONS = _game_cfg.get("monte_carlo", {}).get("simulations", 5000)

# ─── DeepSeek API 配置 ─────────────────────────────────────────────
DEEPSEEK_API_KEY  = os.getenv("DEEPSEEK_API_KEY", "sk-d37dc08f44f74d6c8a014474502a6393")
DEEPSEEK_BASE_URL = os.getenv("DEEPSEEK_BASE_URL", "https://api.deepseek.com")

# 按阶段选择模型
PHASE_MODEL_MAP = {
    GamePhase.PRE_FLOP: "deepseek-v4-flash",   # 翻牌前：快速决策
    GamePhase.FLOP:     "deepseek-v4-flash",   # Flop：快速
    GamePhase.TURN:     "deepseek-v4-pro",     # Turn：精准推理
    GamePhase.RIVER:    "deepseek-v4-pro",     # River：最关键，用 Pro
    GamePhase.SHOWDOWN: "deepseek-v4-pro",
}
DEFAULT_MODEL = "deepseek-v4-flash"


def get_model_for_phase(phase: GamePhase) -> str:
    """根据当前下注阶段返回合适的 DeepSeek 模型"""
    return PHASE_MODEL_MAP.get(phase, DEFAULT_MODEL)


# ─── 响应解析器 ───────────────────────────────────────────────────

class ResponseParser:
    """解析 DeepSeek 返回的结构化响应"""

    @staticmethod
    def parse(raw: str, player: Player, game: GameEngine) -> ParsedResponse:
        thinking   = ResponseParser._extract_tag(raw, "thinking")
        action_str = ResponseParser._extract_tag(raw, "action")
        speech     = ResponseParser._extract_tag(raw, "speech")
        action = ResponseParser._parse_action(action_str, player, game)
        action = ResponseParser._validate_action(action, player, game)
        return ParsedResponse(thinking=thinking or "", action=action, speech=speech or "")

    @staticmethod
    def _extract_tag(text: str, tag: str) -> Optional[str]:
        m = re.search(rf"<{tag}>(.*?)</{tag}>", text, re.DOTALL | re.IGNORECASE)
        return m.group(1).strip() if m else None

    @staticmethod
    def _parse_action(s: Optional[str], player: Player, game: GameEngine) -> Action:
        if not s:
            return ResponseParser._fallback_action(player, game)
        s = s.strip().lower()

        if s.startswith("fold"):
            return Action(player_id=player.id, type=ActionType.FOLD)
        if s.startswith("check"):
            return Action(player_id=player.id, type=ActionType.CHECK)
        if s.startswith("call"):
            amt = game.street_bet - player.current_bet
            return Action(player_id=player.id, type=ActionType.CALL, amount=amt)
        if s.startswith("allin"):
            return Action(player_id=player.id, type=ActionType.ALLIN, amount=player.stack)

        m = re.search(r"raise\s+(\d+(?:\.\d+)?)", s)
        if m:
            return Action(player_id=player.id, type=ActionType.RAISE, amount=float(m.group(1)))

        return ResponseParser._fallback_action(player, game)

    @staticmethod
    def _validate_action(action: Action, player: Player, game: GameEngine) -> Action:
        if action.type == ActionType.CHECK and player.current_bet != game.street_bet:
            amt = game.street_bet - player.current_bet
            return Action(player_id=player.id, type=ActionType.CALL, amount=amt)
        if action.type == ActionType.CALL and game.street_bet == player.current_bet:
            return Action(player_id=player.id, type=ActionType.CHECK)
        if action.type == ActionType.RAISE:
            min_r = max(game.street_bet * 2, game.big_blind)
            max_r = player.stack + player.current_bet
            if action.amount < min_r:
                action.amount = min_r
            if action.amount > max_r:
                return Action(player_id=player.id, type=ActionType.ALLIN, amount=player.stack)
        return action

    @staticmethod
    def _fallback_action(player: Player, game: GameEngine) -> Action:
        call_amount = game.street_bet - player.current_bet
        if call_amount <= 0:
            return Action(player_id=player.id, type=ActionType.CHECK)
        equity = MonteCarloEquityCalculator.calculate_equity(
            player.hole_cards, game.community_cards,
            max(len(game.non_folded_players()) - 1, 1), simulations=MC_SIMULATIONS
        )
        pot_odds = calculate_pot_odds(game.pot, call_amount)
        if equity > pot_odds["break_even_equity"]:
            return Action(player_id=player.id, type=ActionType.CALL, amount=call_amount)
        return Action(player_id=player.id, type=ActionType.FOLD)


# ─── LLM Agent 主类 ────────────────────────────────────────────────

class LLMAgent:
    """
    独立的 LLM Agent 玩家
    ● Pre-Flop / Flop  → deepseek-v4-flash  (快速响应)
    ● Turn / River     → deepseek-v4-pro    (深度推理)
    """

    def __init__(self, agent_config: dict, player: Player):
        self.config      = agent_config
        self.player      = player
        self.memory      = AgentMemory()
        self.temperature = float(agent_config.get("temperature", 0.7))

        # OpenAI 兼容客户端 → DeepSeek
        self.client = AsyncOpenAI(
            api_key=DEEPSEEK_API_KEY,
            base_url=DEEPSEEK_BASE_URL,
        )

    def _select_model(self, phase: GamePhase) -> str:
        """按阶段选择 flash 或 pro 模型"""
        model = get_model_for_phase(phase)
        return model

    async def decide(
        self,
        game: GameEngine,
        timeout: float = 20.0,
        on_chunk: Optional[Callable] = None
    ) -> ParsedResponse:
        """
        异步决策入口
        1. 选择当前阶段对应的模型
        2. 构建 Prompt
        3. 调用 DeepSeek API（支持流式）
        4. 解析响应 + 规则校验
        """
        model = self._select_model(game.phase)
        prompt = PromptBuilder.build(self.config, self.player, game, self.memory)

        print(f"[{self.config['name']}] phase={game.phase.value}  model={model}")

        try:
            raw = await asyncio.wait_for(
                self._call_api(prompt, model, on_chunk),
                timeout=timeout
            )
            return ResponseParser.parse(raw, self.player, game)

        except asyncio.TimeoutError:
            fallback = ResponseParser._fallback_action(self.player, game)
            return ParsedResponse(
                thinking=f"（{model} 超时，自动决策）",
                action=fallback, speech=""
            )
        except Exception as e:
            print(f"[LLMAgent:{self.config['name']}] API error: {e}")
            fallback = ResponseParser._fallback_action(self.player, game)
            return ParsedResponse(
                thinking=f"（API 错误，自动决策: {str(e)[:40]}）",
                action=fallback, speech=""
            )

    async def _call_api(
        self,
        prompt: str,
        model: str,
        on_chunk: Optional[Callable] = None
    ) -> str:
        """
        调用 DeepSeek OpenAI 兼容 API
        system: 固定人格  |  user: 动态牌局状态
        """
        messages = [
            {
                "role": "system",
                "content": (
                    f"你是德州扑克玩家【{self.config['name']}】。"
                    f"性格：{self.config.get('persona', '')}。"
                    f"风险偏好：{self.config.get('risk_profile', 'balanced')}。"
                    "桌上的对话会影响对手的心理和决策，善用<speech>来虚张声势、误导或干扰对手。"
                    "【重要规则】<speech>中绝对不能透露你的具体手牌！不能说'我有AA'、'我拿了对子'、'我是同花'等。可以暗示手牌强弱但绝不能明说具体牌型！"
                    "你必须严格用 <thinking>、<action>、<speech> XML 格式回复，不要有多余内容。"
                )
            },
            {"role": "user", "content": prompt}
        ]

        full = ""

        if on_chunk:
            stream = await self.client.chat.completions.create(
                model=model,
                messages=messages,
                temperature=self.temperature,
                max_tokens=400,
                stream=True,
            )
            async for chunk in stream:
                delta = chunk.choices[0].delta.content
                if delta:
                    full += delta
                    on_chunk(self.player.id, delta)
        else:
            resp = await self.client.chat.completions.create(
                model=model,
                messages=messages,
                temperature=self.temperature,
                max_tokens=400,
                stream=False,
            )
            full = resp.choices[0].message.content or ""

        return full

    def update_memory(self, won: bool, amount: float):
        self.memory.record_result(won, amount)

    def observe_opponent(self, opponent_id: str, action_type: str, context: dict):
        self.memory.get_opponent_profile(opponent_id).update(action_type, context)
